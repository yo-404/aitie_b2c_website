/* Shared navbar component, injected into #global-navbar-mount.
   Matches the navbar in index_pink.html with full Webflow IX interactions. */
(function () {
    var navMount = document.getElementById('global-navbar-mount');
    if (!navMount) return;

    var css = ''
        + '.nav-logo-desktop .logo-wrap,.nav-logo-mobile .logo-wrap{mix-blend-mode:difference;}'
        + '.nav_background,.w-nav,.nav,.navbar,.nav_wrap,.nav-container,.nav-04-container,.navbar-holder,.w-layout-vflex,.nav-logo-desktop,.nav-logo-mobile,.nav-logo-wrap,.nav-logo-link{background:transparent !important;background-color:transparent !important;box-shadow:none !important;}'
        + '.nav-menu-links{background-color:#000 !important;border-color:rgba(84,87,132,.25) !important;}'
        + '.nav_buttons-wrap .button{position:relative;overflow:hidden;display:inline-flex;align-items:center;justify-content:center;}'
        + '.nav_buttons-wrap .button .button-text{transition:transform .35s cubic-bezier(.16,1,.3,1),opacity .35s ease;}'
        + '.nav_buttons-wrap .button .button-text-2nd{position:absolute;top:100%;left:0;width:100%;text-align:center;transition:transform .35s cubic-bezier(.16,1,.3,1),opacity .35s ease;}'
        + '.nav_buttons-wrap .button:hover .button-text{transform:translateY(-100%);}'
        + '.nav_buttons-wrap .button:hover .button-text-2nd{transform:translateY(-100%);}'
        + '.nav-link-wrap a.nav-link{transition:opacity .25s ease,color .25s ease;}'
        + '.nav-link-wrap a.nav-link:hover{opacity:.7;}'
        + '.w-webflow-badge,.buy-template-panel{display:none !important;visibility:hidden !important;opacity:0 !important;pointer-events:none !important;}';

    var styleEl = document.createElement('style');
    styleEl.textContent = css;
    document.head.appendChild(styleEl);

    var navHtml = ''
        + '<div mdlfy-content="component" class="nav_wrap">'
        + '  <div class="navbar">'
        + '    <div data-w-id="1d33f374-784d-2d4e-f557-d2a85347d2a6" data-animation="default" data-collapse="medium" data-duration="400" data-easing="ease" data-easing2="ease" role="banner" class="nav w-nav">'
        + '      <div class="container-medium nav-container nav-04-container">'
        + '        <div class="w-layout-vflex navbar-holder">'
        + '          <div class="nav-logo-mobile"><a href="/" class="nav-logo-link w-nav-brand">'
        + '              <div class="nav-logo-wrap">'
        + '                <div class="logo-wrap"><img loading="lazy" src="images/logotype_black.svg" alt="Logo" class="logo-image" /></div>'
        + '              </div>'
        + '            </a></div>'
        + '          <nav role="navigation" class="nav-menu-button w-nav-menu">'
        + '            <div class="nav-logo-desktop"><a href="/" class="nav-logo-link w-nav-brand">'
        + '                <div class="nav-logo-wrap">'
        + '                  <div class="logo-wrap"><img loading="lazy" src="images/logotype_black.svg" alt="Logo" class="logo-image" /></div>'
        + '                </div>'
        + '              </a></div>'
        + '            <div class="nav-menu-links">'
        + '              <div class="nav-link-wrap"><a href="/" class="nav-link w-inline-block"><p>Home</p></a></div>'
        + '              <div class="nav-link-wrap"><a href="about.html" class="nav-link w-inline-block"><p>About</p></a></div>'
        + '              <div class="nav-link-wrap flex-center"><div><a href="/feature" class="nav-link w-inline-block"><p>Features</p></a></div></div>'
        + '              <div class="nav-link-wrap flex-center"><div><a href="/blog" class="nav-link w-inline-block"><p>Blog</p></a></div></div>'
        + '            </div>'
        + '            <div class="nav_buttons-wrap">'
        + '              <div><a href="waitlist.html" class="button w-inline-block">'
        + '                  <p class="button-text">Join Waitlist</p>'
        + '                  <p class="button-text-2nd">Join Waitlist</p>'
        + '                </a></div>'
        + '              <div data-w-id="1d33f374-784d-2d4e-f557-d2a85347d2d3" class="nav-icon-holder"><img src="https://cdn.prod.website-files.com/6929b6c693cb856e01ef7c05/692d7284f7e2d2e1e55f3636_Mark.svg" loading="lazy" alt="" class="nav-icon" /></div>'
        + '            </div>'
        + '            <div class="nav_mobile-bg-holder">'
        + '              <div class="nav_background"></div>'
        + '            </div>'
        + '          </nav>'
        + '          <div class="nav_mobile-bg-holder">'
        + '            <div class="nav_background"></div>'
        + '          </div>'
        + '          <div class="nav_menu-button w-nav-button">'
        + '            <div class="menu_icon-wrap">'
        + '              <div class="menu_line-top"></div>'
        + '              <div class="menu_line-middle"></div>'
        + '              <div class="menu_line-bottom"></div>'
        + '            </div>'
        + '          </div>'
        + '        </div>'
        + '      </div>'
        + '    </div>'
        + '  </div>'
        + '</div>';

    navMount.outerHTML = navHtml;
})();
